clear all; close all; 
% -------------------------------------------------------------------------
load hyperpara;
% hyperpara contains the following parameters:
% NN (17x1) : age distribution of population
% Chome   (17x17) : contact matrix for contacts at home
% Cwork   (17x17) : contact matrix for contacts at work
% Cschool (17x17) : contact matrix for contacts at school
% Cother  (17x17) : contact matrix for contacts at other location
% HOSP    (17x1)  : transfer from self-isolation to MCU
% ICU     (17x1)  : transfer from MCU to ICU
% PROBC   (17x6)   : daily probability of death in self-isolation
% PROBH   (17x7)   : daily probability of death in MCU
% PROBQ   (17x8)   : daily probability of death in ICU
% SYM     (scalar): fraction of symptomatic
% -------------------------------------------------------------------------
% INPUT:
%   DT  (days)       : start date of epidemic before March 1
%   duration  (days) : duration of interest after March 1 
DT       = 22;
duration = DT+605;
% effective contact matrices:
%   CM0 : effective contact matrix befoe raising awareness in population
CM0      = Chome + Cschool + Cwork + Cother;
%   CM1 : effective contact matrix after raising awareness in population
CM1      = 0.5*CM0;
%   CM2 : effective contact matrix for extraordinary state
CM2      = 0.5*(1.225*Chome + 0.1*0.25*Cother + 0.3*0.50*Cwork + 0.*Cschool);
%   CMi : contact matrices after relaxation
CM3      = 0.5*(1.210*Chome + 0.1*0.40*Cother + 0.3*0.55*Cwork + 0.*Cschool); % after Apr 27
CM4      = 0.5*(1.110*Chome + 0.1*0.55*Cother + 0.3*0.65*Cwork +    Cschool); %after May 11
CM5      = 0.5*(1.105*Chome + 0.3*0.70*Cother + 0.3*0.65*Cwork +    Cschool); %after June 8
% -------------------------------------------------------------------------
% probabilities of transmission
% betaA : transmission for asymtomatic infected 
% betaB : transmission for symtomatic infected 
betaB = 0.0898; 
betaA = 2/3*betaB;
% -------------------------------------------------------------------------
% INITIALIZE STATE VARIABLES
% R00 : Reproduction number (average over population)
R0      =  ((1-SYM)*8*betaA + SYM*2*betaB)*(1./NN).*(CM0'*NN);
R00(1)  =  (NN'*R0)/sum(NN);
S(:,1)  =  NN;           % susceptibles
E1(:,1) =  zeros(17,1);  % exposed
E2(:,1) =  zeros(17,1); 
E3(:,1) =  zeros(17,1); 
E4(:,1) =  zeros(17,1); 
E5(:,1) =  zeros(17,1); 
E(:,1)  =  zeros(17,1); 
Aold    =   ones(17,8);  % asymptomatic
A(:,1)  = 8*ones(17,1);
B1(:,1) =   ones(17,1);  
B2(:,1) =   ones(17,1);
B(:,1)  = 2*ones(17,1);  % symptomatic
Cold    =  zeros(17,6);  % self-isolated
Hold    =  zeros(17,7);  % hospitalized MCU
Qold    =  zeros(17,8);  % hospitalied ICU
D(:,1)  =  zeros(17,1);  % total of deaths
DC(:,1) =  zeros(17,1);  % deaths in self-isolation
DH(:,1) =  zeros(17,1);  % deaths in MCU
DQ(:,1) =  zeros(17,1);  % deaths in ICU
weights =  ones(8,1);
% -------------------------------------------------------------------------
% BEGIN TIME INTEGRATION
mtime(1)= 0; %t=1 corresponds to mtime = 0;
for t=1:duration 
mtime(t+1)=t;
% step 1: compute effective contact matrix for current time
    CM=CM0;
    T1=7; T2=13; T3=23.5;
    af=(exp(1)-1)/(T2-T1);
    bf= exp(1) - af*T2;
if t>DT+T1
    alpha=log(af*(t-DT)+bf);
    CM= (1-alpha)*CM0 + alpha*CM1;
end
af=(exp(1)-1)/(T3-T2); bf=exp(1)-af*T3;
if t>DT+T2
    alpha=log(af*(t-DT)+bf);
    CM=(1-alpha)*CM1+alpha*CM2;
end
if t>DT+T3
    CM=CM2;
end
if t>DT+58 % 27 Apr
    CM=CM3;
end
if t>DT+72 % 11 May 
    CM=CM4;
end
if t>DT+100 % 8 June 
    CM=CM5;
end
% step 2: compute newly exposed
dS        = -S(:,t).*(CM*(betaA*(...
Aold(:,1)+...
Aold(:,2)+...
Aold(:,3)+...
Aold(:,4)+...
Aold(:,5)+...
Aold(:,6)+...
Aold(:,7)+...
Aold(:,8)...
)./NN+betaB*(B(:,t))./NN));
S(:,t+1)  = S(:,t) + dS;
% step 3: propagate exposed
E1(:,t+1) = -dS; 
E2(:,t+1) = E1(:,t);
E3(:,t+1) = E2(:,t);
E4(:,t+1) = E3(:,t);
E5(:,t+1) = E4(:,t);
% sum of currently exposed (by age-group)
E(:,t+1)  = E1(:,t+1)+E2(:,t+1)+E3(:,t+1)+E4(:,t+1)+E5(:,t+1);
% step 4: propagate asymtomatic
Anew(:,1) = E5(:,t)*(1-SYM);
Anew(:,2) = Aold(:,1);
Anew(:,3) = Aold(:,2);
Anew(:,4) = Aold(:,3);
Anew(:,5) = Aold(:,4);
Anew(:,6) = Aold(:,5);
Anew(:,7) = Aold(:,6);
Anew(:,8) = Aold(:,7);
% step 5: propagate symptomatic
B1(:,t+1) = E5(:,t)*SYM;
B2(:,t+1) = B1(:,t);
B(:,t+1)  = B1(:,t+1) + B2(:,t+1);
% step 6: propagate self-isolated
Cnew(:,1) = B2(:,t);                                DC1=Cold(:,1).*PROBC(:,1);
Cnew(:,2) = Cold(:,1).*(1-PROBC(:,1));              DC2=Cold(:,2).*PROBC(:,2);
Cnew(:,3) = Cold(:,2).*(1-PROBC(:,2));              DC3=Cold(:,3).*PROBC(:,3);
Cnew(:,4) = Cold(:,3).*(1-PROBC(:,3));              DC4=Cold(:,4).*PROBC(:,4);
Cnew(:,5) = Cold(:,4).*(1-PROBC(:,4));              DC5=Cold(:,5).*PROBC(:,5);
Cnew(:,6) = Cold(:,5).*(1-PROBC(:,5)).*(1-HOSP);    DC6=Cold(:,6).*PROBC(:,6);
% accumlated deaths in self-isolation
DC(:,t+1) = DC(:,t) + DC1 + DC2 + DC3 + DC4 + DC5 + DC6;
% step 7: propagate hospitalized (MCU)
Hnew(:,1) = Cold(:,5).*(1-PROBC(:,5)).*HOSP;        DH1=Hold(:,1).*PROBH(:,1);
Hnew(:,2) = Hold(:,1).*(1-PROBH(:,1));              DH2=Hold(:,2).*PROBH(:,2);
Hnew(:,3) = Hold(:,2).*(1-PROBH(:,2)).*(1-ICU);     DH3=Hold(:,3).*PROBH(:,3);
Hnew(:,4) = Hold(:,3).*(1-PROBH(:,3));              DH4=Hold(:,4).*PROBH(:,4);
Hnew(:,5) = Hold(:,4).*(1-PROBH(:,4));              DH5=Hold(:,5).*PROBH(:,5);
Hnew(:,6) = Hold(:,5).*(1-PROBH(:,5));              DH6=Hold(:,6).*PROBH(:,6);
Hnew(:,7) = Hold(:,6).*(1-PROBH(:,6));              DH7=Hold(:,7).*PROBH(:,7);
% sum of currently hospitalized in MCU (by age-group)
H(:,t+1)  = Hnew(:,1)+Hnew(:,2)+Hnew(:,3)+Hnew(:,4)+Hnew(:,5)+Hnew(:,6)+Hnew(:,7);
% accumlated deaths in MCU
DH(:,t+1) = DH(:,t) + DH1 + DH2 + DH3 + DH4 + DH5 + DH6 + DH7; 
% step 8: propagate hospitalized (ICU)
Qnew(:,1) = Hold(:,2).*(1-PROBH(:,2)).*ICU;         DQ1=Qold(:,1).*PROBQ(:,1);
Qnew(:,2) = Qold(:,1).*(1-PROBQ(:,1));              DQ2=Qold(:,2).*PROBQ(:,2);
Qnew(:,3) = Qold(:,2).*(1-PROBQ(:,2));              DQ3=Qold(:,3).*PROBQ(:,3);
Qnew(:,4) = Qold(:,3).*(1-PROBQ(:,3));              DQ4=Qold(:,4).*PROBQ(:,4);
Qnew(:,5) = Qold(:,4).*(1-PROBQ(:,4));              DQ5=Qold(:,5).*PROBQ(:,5);
Qnew(:,6) = Qold(:,5).*(1-PROBQ(:,5));              DQ6=Qold(:,6).*PROBQ(:,6);
Qnew(:,7) = Qold(:,6).*(1-PROBQ(:,6));              DQ7=Qold(:,7).*PROBQ(:,7);
Qnew(:,8) = Qold(:,7).*(1-PROBQ(:,7));              DQ8=Qold(:,8).*PROBQ(:,8);
% sum of currently hospitalized in ICU (by age group)
Q(:,t+1)  = Qnew(:,1)+Qnew(:,2)+Qnew(:,3)+Qnew(:,4)+Qnew(:,5)+Qnew(:,6)+Qnew(:,7)+Qnew(:,8);
% accumlated deaths in ICU
DQ(:,t+1) = DQ(:,t) + DQ1 + DQ2 + DQ3 + DQ4 + DQ5 + DQ6 + DQ7 + DQ8;
% step 9: update state variables
Aold      = Anew;
Cold      = Cnew;
Hold      = Hnew;
Qold      = Qnew;
% step 10: compute reproduction number
SCURRENT = S(:,t+1);
ECURRENT = E(:,t+1);
R0       = ((1-SYM)*8*betaA + SYM*2*betaB)*(1./NN).*(CM'*SCURRENT);
R00(t+1) = (ECURRENT'*R0)/sum(ECURRENT);
end
% -------------------------------------------------------------------------
% POST-PROCESSING
D = DC + DH + DQ; % all deceased by age-group (as function of time)
Dtot=sum(D);      % total of deceased (as function of time)
Htot=sum(H);      % total of hospitalized in MCU (as a function of time)
Qtot=sum(Q);      % total of hospitalized in ICU (as a function of time)
%